# Find-Leap-Year
This is Code to find Leap year Just enter any year you want to and then it will tell  whether it is leap year or not.
